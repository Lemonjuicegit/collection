const delURL = 1
const editURLName = 2
const addURL = 4
const permissions = [delURL, editURLName, addURL]
export default permissions